# Create Question 2 PNG
# Have total emissions from PM2.5 decreased in the Baltimore City, Maryland (fips == "24510") 
# from 1999 to 2008? Use the base plotting system to make a plot answering this question.

# get the zip for all the data, if needed
if(!file.exists("summarySCC_PM25.rds") || !file.exists("Source_Classification_Code.rds") ){
    if(!file.exists("data.zip")){
        download.file("https://d396qusza40orc.cloudfront.net/exdata%2Fdata%2FNEI_data.zip"
                    , destfile = "data.zip")
    }
    unzip("data.zip")
}

# read in the data 
############################
nei <- readRDS("summarySCC_PM25.rds") # will take a while to process on most machines
scc <- readRDS("Source_Classification_Code.rds")

# good idea to make this factor
nei$type <- as.factor(nei$type)

#subset & prepare the data
############################
baltimore <- nei[nei$fips == "24510", ] # all columns for Baltimore rows only

# sum the Emissions by year
x <- aggregate(Emissions ~ year, data=baltimore, sum)

#tidy results so it plots more clearly
x$year <- as.factor(x$year)
x$year <- as.character(x$year)


options(scipen=5) # turn off scientific notation so the axes look readable!

# Output to a file
png(filename="plot2.png")


# use a barplot
barplot(x$Emissions, 
	xlab="Year", ylab="Emissions (tons)", 
	col="blue", 
	names.arg=x$year, 
	main="Baltimore: Total PM2.5 emissions (all sources) 1999-2008")

dev.off() 