# Create Question 3 PNG, use ggplot to show breakdown by type for PM25 pollution in Baltimore.

# get the zip for all the data, if needed
if(!file.exists("summarySCC_PM25.rds") || !file.exists("Source_Classification_Code.rds") ){
    if(!file.exists("data.zip")){
        download.file("https://d396qusza40orc.cloudfront.net/exdata%2Fdata%2FNEI_data.zip"
                    , destfile = "data.zip")
    }
    unzip("data.zip")
}

#read in the data 
###########################
nei <- readRDS("summarySCC_PM25.rds") # will take a while to process on most machines
scc <- readRDS("Source_Classification_Code.rds")

require(ggplot2)

# good idea to make this factor
nei$type <- as.factor(nei$type)

#subset & prepare the data
############################
baltimore <- nei[nei$fips == "24510", ] # all columns for Baltimore rows only

types <- levels(baltimore$type)
totals.types <- data.frame() # we will store all our totals in here

# loop trhough and build up a dataframe with each factor level of type and its aggregate totals.
for (i in types) {

	append <- baltimore[baltimore$type == i, ]

	# sum the Emissions by year
	df <- aggregate(Emissions ~ year, data=append, sum)

	# add in an extra column for this factor, we can then just show facets in our plot later:
	df$type <- rep(i, 4)

	#append it to our main dataframe:
	totals.types <- rbind(totals.types, df)
}


# make data tidy for the plot to work automatically:
totals.types$type <- as.factor(totals.types$type)
totals.types$year <- as.character(totals.types$year)

# turn off scientific notation so the axes look readable!
options(scipen=5)

# Output to a PNG file
png(filename="plot3.png", width=800, height=600)

g <- ggplot(totals.types, aes(year, Emissions))

# use the facet and also colours to show breakdown by the "type"
# and use a linear model best fit to show the trend. 
p <- g + geom_point(aes(color=type), size=4) + facet_grid( . ~ type) + labs(x = "Year", y="Emissions (tons)", 
	title="Baltimore: Total PM2.5 emissions (by source type) 1999-2008") + stat_smooth( method="lm", se=FALSE, aes(group=1)) + geom_line(aes(group=1)) + theme(axis.title.x=element_text(size=15), axis.title.y=element_text(size=15), 
	plot.title=element_text(size=18, face="bold", vjust=1.5)) 

#explicitly print to our file
print(p)

dev.off() 