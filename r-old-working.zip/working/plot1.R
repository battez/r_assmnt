# Create Question 1 PNG
# Have total emissions from PM2.5 decreased in the United States from 1999 to 2008? 
# Using the base plotting system, make a plot showing the total PM2.5 emission 
# from all sources for each of the years 1999, 2002, 2005, and 2008.

# get the zip for all the data, if needed
if(!file.exists("summarySCC_PM25.rds") || !file.exists("Source_Classification_Code.rds") ){
    if(!file.exists("data.zip")){
        download.file("https://d396qusza40orc.cloudfront.net/exdata%2Fdata%2FNEI_data.zip"
                    , destfile = "data.zip")
    }
    unzip("data.zip")
}

# read in the data
############################
nei <- readRDS("summarySCC_PM25.rds") # will take a while to process on most machines
scc <- readRDS("Source_Classification_Code.rds")

# good idea to make this factor
nei$type <- as.factor(nei$type)

#subset & prepare the data
############################

# sum the Emissions by year
x <- aggregate(Emissions ~ year, data=nei, sum)

#tidy results so it plots more clearly
x$year <- as.factor(x$year)
x$year <- as.character(x$year)


options(scipen=5) # turn off scientific notation so the axes look readable!
# Output to a file
png(filename="plot1.png")

# make a colour range that will illustrate the meaning of the decline in pollution:
pal <- colorRampPalette(c("red", "yellow"))

# use a barplot
barplot(x$Emissions, 
	xlab="Year", ylab="Emissions (tons)", 
	col=pal(4), 
	names.arg=x$year, 
	main="U.S. Total PM2.5 emissions (all sources) 1999-2008")
dev.off() 