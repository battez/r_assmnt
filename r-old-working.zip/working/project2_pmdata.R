# WEEK3 ~ ASSIGNMENT 2
# by John Barker
# project2_pmdata.R


# data <- read.table("summarySCC_PM25.rds",sep=";",header = TRUE,na.strings="?"
#                    ,
#                    colClasses = c("character","character","character","numeric","character","Date"))
#                    


head(snei)
print(head(snei))                   
