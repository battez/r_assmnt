# Create Question 5 PNG, 
# How have emissions from motor vehicle sources changed from 1999–2008 in Baltimore City?
# 
# get the zip for all the data, if needed
if(!file.exists("summarySCC_PM25.rds") || !file.exists("Source_Classification_Code.rds") ){
    if(!file.exists("data.zip")){
        download.file("https://d396qusza40orc.cloudfront.net/exdata%2Fdata%2FNEI_data.zip"
                    , destfile = "data.zip")
    }
    unzip("data.zip")
}

#read in the data 
###########################
nei <- readRDS("summarySCC_PM25.rds") # will take a while to process on most machines
scc <- readRDS("Source_Classification_Code.rds")



# good idea to make this factor
nei$type <- as.factor(nei$type)

#subset & prepare the data
############################
#
# Any of the Sector with "Vehicles" in 
vehicles <- scc[grep("Vehicles", scc$EI.Sector), 1] # vector with codes in. Will search on these next.


# subset to Baltimore only:
baltimore <- nei[nei$fips == "24510", ]

# get valid subset of data:
valid <- baltimore[baltimore$SCC %in% vehicles , ]

# merge the subset and lookup info. to get all columns we might need:
allcols <- merge(valid, scc[c(1,3,4)], "SCC") # TODO: use this to possibly show breakdown by source?

# sum the Emissions by year
totals <- aggregate(Emissions ~ year, data=allcols, sum)
totals$year <- as.character(totals$year)

# use GGPlot2
require(ggplot2)

# turn off scientific notation so the axes look readable!
options(scipen=5)

# Output to a PNG file
png(filename="plot5.png", width=800, height=600)

g <- ggplot(totals, aes(year, Emissions))

p <- g + geom_point(color="green", size=4) +  labs(x = "Year", y="Emissions (tons)", 
	title="Baltimore Total Motor Vehicle PM2.5 emissions  1999-2008")  + geom_line(aes(group=1)) + theme(axis.title.x=element_text(size=15), axis.title.y=element_text(size=15), 
	plot.title=element_text(size=18, face="bold", vjust=1.5)) 

#explicitly print to our file
print(p)

dev.off() 